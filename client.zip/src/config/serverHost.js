export const serverHost = {
    host: "http://localhost:3300",
    db:"mongodb+srv://kshuyz0055:kshuyz0055@cluster0.vnwhw.mongodb.net/Dist?retryWrites=true&w=majority"
  };